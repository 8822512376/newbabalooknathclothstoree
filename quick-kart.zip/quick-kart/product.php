<?php
include 'common/header.php';

if (!is_user_logged_in()) {
    header("Location: login.php");
    exit();
}

// --- DATA FETCHING LOGIC ---
$cat_id = isset($_GET['cat_id']) ? (int)$_GET['cat_id'] : 0;
$sort_by = isset($_GET['sort']) ? $_GET['sort'] : 'new';
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';

$where_clauses = [];
$params = [];
$types = '';

if ($cat_id > 0) {
    $where_clauses[] = "cat_id = ?";
    $params[] = $cat_id;
    $types .= 'i';
}

if (!empty($search_term)) {
    $where_clauses[] = "name LIKE ?";
    $search_param = "%" . $search_term . "%";
    $params[] = $search_param;
    $types .= 's';
}

$sql = "SELECT id, name, price, image FROM products";
if (!empty($where_clauses)) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}

// Sorting logic
switch ($sort_by) {
    case 'price_asc':
        $sql .= " ORDER BY price ASC";
        break;
    case 'price_desc':
        $sql .= " ORDER BY price DESC";
        break;
    default: // 'new'
        $sql .= " ORDER BY created_at DESC";
}

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$products_result = $stmt->get_result();

// Fetch category name if cat_id is set
$category_name = 'All Products';
if ($cat_id > 0) {
    $cat_stmt = $conn->prepare("SELECT name FROM categories WHERE id = ?");
    $cat_stmt->bind_param("i", $cat_id);
    $cat_stmt->execute();
    $cat_result = $cat_stmt->get_result();
    if ($cat_row = $cat_result->fetch_assoc()) {
        $category_name = $cat_row['name'];
    }
    $cat_stmt->close();
}
?>

<main class="p-4">
    <div class="flex justify-between items-center mb-4">
        <h1 class="text-xl font-bold text-gray-800"><?php echo htmlspecialchars($category_name); ?></h1>
        <!-- Filter/Sort Dropdown could go here -->
    </div>

    <!-- Products Grid -->
    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        <?php if ($products_result->num_rows > 0): ?>
            <?php while($product = $products_result->fetch_assoc()): ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden transform transition duration-300 hover:scale-105">
                <a href="product_detail.php?id=<?php echo $product['id']; ?>">
                    <img src="uploads/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="w-full h-32 object-cover">
                </a>
                <div class="p-3">
                    <h3 class="text-sm font-semibold text-gray-800 truncate"><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p class="text-md font-bold text-indigo-600 mt-1"><?php echo format_price($product['price']); ?></p>
                    <button onclick="addToCart(<?php echo $product['id']; ?>)" class="w-full mt-2 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-500 rounded-md hover:bg-indigo-600 transition">
                        Add to Cart
                    </button>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="col-span-full text-center text-gray-500 mt-8">No products found in this category.</p>
        <?php endif; ?>
    </div>
</main>

<script>
    // --- ADD TO CART (AJAX) ---
    async function addToCart(productId) {
        const formData = new FormData();
        formData.append('action', 'add');
        formData.append('product_id', productId);
        formData.append('quantity', 1);

        const result = await sendRequest('cart.php', {
            method: 'POST',
            body: formData
        });
        
        if (result.success) {
            // You can add a success toast/notification here
            alert(result.message); 
        } else {
            alert(result.message || 'Failed to add item to cart.');
        }
    }
</script>

<?php 
$stmt->close();
include 'common/bottom.php'; 
?>