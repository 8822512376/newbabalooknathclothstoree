<?php
include 'common/header.php';

$users_result = $conn->query("SELECT id, name, email, phone, created_at FROM users ORDER BY created_at DESC");
?>
<div class="bg-white p-5 rounded-lg shadow-sm">
    <h2 class="text-xl font-semibold mb-4">Registered Users</h2>
    <div class="overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                <tr>
                    <th class="px-6 py-3">User ID</th>
                    <th class="px-6 py-3">Name</th>
                    <th class="px-6 py-3">Email</th>
                    <th class="px-6 py-3">Phone</th>
                    <th class="px-6 py-3">Registered On</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($user = $users_result->fetch_assoc()): ?>
                <tr class="bg-white border-b hover:bg-gray-50">
                    <td class="px-6 py-4 font-bold">#<?php echo $user['id']; ?></td>
                    <td class="px-6 py-4"><?php echo htmlspecialchars($user['name']); ?></td>
                    <td class="px-6 py-4"><?php echo htmlspecialchars($user['email']); ?></td>
                    <td class="px-6 py-4"><?php echo htmlspecialchars($user['phone']); ?></td>
                    <td class="px-6 py-4"><?php echo date('d M, Y', strtotime($user['created_at'])); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include 'common/bottom.php'; ?>