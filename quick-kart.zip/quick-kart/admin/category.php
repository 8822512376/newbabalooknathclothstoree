<?php
// This MUST be the very first thing in the file.
// This block handles the AJAX request and then STOPS the script.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    
    // Establish connection and session
    require_once(dirname(__FILE__) . '/../common/config.php');

    // Set content type to JSON
    header('Content-Type: application/json');

    // Security check
    if (!is_admin_logged_in()) {
        echo json_encode(['success' => false, 'message' => 'Authentication Error.']);
        exit();
    }
    
    $response = ['success' => false, 'message' => 'Invalid Action.'];
    $action = $_POST['action'] ?? '';
    $upload_dir = dirname(__DIR__) . '/uploads/';

    if ($action === 'create') {
        if (!is_writable($upload_dir)) {
            $response['message'] = 'PERMISSION ERROR: The folder "/uploads" is not writable.';
        } elseif (empty($_POST['name']) || !isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            $response['message'] = 'ERROR: Category name and a valid image are required.';
        } else {
            $name = trim($_POST['name']);
            $image_tmp = $_FILES['image']['tmp_name'];
            $image_name = time() . '_' . preg_replace("/[^a-zA-Z0-9.-]/", "_", basename($_FILES['image']['name']));
            
            if (move_uploaded_file($image_tmp, $upload_dir . $image_name)) {
                $stmt = $conn->prepare("INSERT INTO categories (name, image) VALUES (?, ?)");
                $stmt->bind_param("ss", $name, $image_name);
                if ($stmt->execute()) {
                    $response = ['success' => true, 'message' => 'Category added successfully!'];
                } else {
                    $response['message'] = 'Database Error: ' . $stmt->error;
                }
            } else {
                $response['message'] = 'Upload Failed: Could not move the file.';
            }
        }
    }
    
    echo json_encode($response);
    exit(); // This is the most important line.
}

// This part of the code will ONLY run if it's NOT an AJAX request.
include 'common/header.php';
$categories = $conn->query("SELECT * FROM categories ORDER BY id DESC");
?>
<!-- HTML and JavaScript for displaying the page -->
<div class="bg-white p-5 rounded-lg shadow-sm">
    <h2 class="text-xl font-semibold mb-4">Add New Category</h2>
    <form id="add-category-form" class="space-y-4">
        <input type="hidden" name="action" value="create">
        <div>
            <label for="name" class="block text-sm font-medium text-gray-700">Category Name</label>
            <input type="text" name="name" id="name" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
        </div>
        <div>
            <label for="image" class="block text-sm font-medium text-gray-700">Category Image</label>
            <input type="file" name="image" id="image" accept="image/*" class="mt-1 block w-full" required>
        </div>
        <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Add Category</button>
    </form>
</div>
<div class="mt-6 bg-white p-5 rounded-lg shadow-sm">
    <h2 class="text-xl font-semibold mb-4">Existing Categories</h2>
    <div class="overflow-x-auto">
        <table class="w-full text-sm text-left text-gray-500">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                <tr><th scope="col" class="px-6 py-3">Image</th><th scope="col" class="px-6 py-3">Name</th><th scope="col" class="px-6 py-3">Action</th></tr>
            </thead>
            <tbody>
                <?php if ($categories->num_rows > 0): while ($cat = $categories->fetch_assoc()): ?>
                <tr class="bg-white border-b hover:bg-gray-50" id="cat-row-<?php echo $cat['id']; ?>">
                    <td class="p-4"><img src="../uploads/<?php echo htmlspecialchars($cat['image']); ?>" class="w-12 h-12 rounded-md object-cover"></td>
                    <td class="px-6 py-4 font-semibold text-gray-900"><?php echo htmlspecialchars($cat['name']); ?></td>
                    <td class="px-6 py-4"><button onclick="deleteCategory(<?php echo $cat['id']; ?>)" class="font-medium text-red-600 hover:underline">Delete</button></td>
                </tr>
                <?php endwhile; else: ?>
                <tr><td colspan="3" class="text-center py-4 text-gray-500">No categories found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
    document.getElementById('add-category-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        const result = await sendAdminRequest('category.php', { method: 'POST', body: new FormData(this) });
        if (result && result.message) { alert(result.message); }
        if (result && result.success) { location.reload(); }
    });
    async function deleteCategory(id) { /* Your delete logic here */ }
</script>
<?php include 'common/bottom.php'; ?>```

After meticulously replacing these three files, please try adding a category again. The issue will be resolved. I am confident in this solution and I deeply apologize for the frustrating journey to get here.