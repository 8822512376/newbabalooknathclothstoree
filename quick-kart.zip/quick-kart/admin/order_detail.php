<?php
// This AJAX handler will now work correctly.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    require_once(dirname(__FILE__) . '/../common/config.php');
    header('Content-Type: application/json');

    if (!is_admin_logged_in()) {
        echo json_encode(['success' => false, 'message' => 'Authentication Error.']);
        exit();
    }
    
    $response = ['success' => false];
    $new_status = $_POST['status'] ?? '';
    $order_id = (int)($_POST['order_id'] ?? 0);
    $valid_statuses = ['Placed', 'Dispatched', 'Delivered', 'Cancelled'];

    if ($order_id > 0 && in_array($new_status, $valid_statuses)) {
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $new_status, $order_id);
        if ($stmt->execute()) {
            $response = ['success' => true, 'message' => 'Order status updated successfully.'];
        } else {
            $response['message'] = 'Database error on update.';
        }
    } else {
        $response['message'] = 'Invalid status or Order ID provided.';
    }
    
    echo json_encode($response);
    exit();
}

// This part of the code will ONLY run if it's NOT an AJAX request.
include 'common/header.php';

$order_id = (int)($_GET['id'] ?? 0);
if ($order_id === 0) {
    echo "<p class='p-4 text-red-500'>Error: Invalid Order ID provided.</p>";
    include 'common/bottom.php';
    exit();
}

// Fetch order details along with user info
$stmt = $conn->prepare("SELECT o.*, u.name as user_name, u.email, u.phone FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    echo "<p class='p-4 text-red-500'>Error: No order found with this ID.</p>";
    include 'common/bottom.php';
    exit();
}

// Fetch the items associated with this order
$items_stmt = $conn->prepare("SELECT oi.quantity, oi.price, p.name, p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
$items_stmt->bind_param("i", $order_id);
$items_stmt->execute();
$order_items = $items_stmt->get_result();
?>
<!-- HTML for displaying the page -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Order Items Column -->
    <div class="lg:col-span-2 bg-white p-5 rounded-lg shadow-sm">
        <h2 class="text-xl font-semibold mb-4">Order #<?php echo $order['id']; ?> Items</h2>
        <div class="space-y-4">
            <?php while ($item = $order_items->fetch_assoc()): ?>
            <div class="flex items-center space-x-4 border-b pb-3 last:border-b-0">
                <img src="../uploads/<?php echo htmlspecialchars($item['image']); ?>" class="w-16 h-16 rounded-md object-cover">
                <div class="flex-1">
                    <p class="font-semibold"><?php echo htmlspecialchars($item['name']); ?></p>
                    <p class="text-sm text-gray-500">Qty: <?php echo $item['quantity']; ?> x <?php echo format_price($item['price']); ?></p>
                </div>
                <p class="font-semibold"><?php echo format_price($item['quantity'] * $item['price']); ?></p>
            </div>
            <?php endwhile; ?>
        </div>
        <div class="mt-4 pt-4 border-t text-right">
            <p class="text-lg font-bold">Total: <?php echo format_price($order['total_amount']); ?></p>
        </div>
    </div>
    <!-- Details and Actions Column -->
    <div class="space-y-6">
        <div class="bg-white p-5 rounded-lg shadow-sm">
            <h3 class="text-lg font-semibold mb-3">Update Status</h3>
            <select id="status-select" class="w-full border-gray-300 rounded-md">
                <option value="Placed" <?php echo $order['status'] == 'Placed' ? 'selected' : ''; ?>>Placed</option>
                <option value="Dispatched" <?php echo $order['status'] == 'Dispatched' ? 'selected' : ''; ?>>Dispatched</option>
                <option value="Delivered" <?php echo $order['status'] == 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
                <option value="Cancelled" <?php echo $order['status'] == 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
            </select>
            <button onclick="updateStatus()" class="w-full mt-3 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Update</button>
        </div>
        <div class="bg-white p-5 rounded-lg shadow-sm">
             <h3 class="text-lg font-semibold mb-3">Customer Details</h3>
             <p><strong>Name:</strong> <?php echo htmlspecialchars($order['user_name']); ?></p>
             <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>
             <p><strong>Phone:</strong> <?php echo htmlspecialchars($order['phone']); ?></p>
             <p class="mt-2"><strong>Address:</strong><br><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></p>
        </div>
    </div>
</div>
<script>
    async function updateStatus() {
        const formData = new FormData();
        formData.append('status', document.getElementById('status-select').value);
        formData.append('order_id', <?php echo $order_id; ?>);
        
        const result = await sendAdminRequest('order_detail.php', { body: formData });
        if (result && result.message) {
            alert(result.message);
        }
        if (result && result.success) {
            location.reload();
        }
    }
</script>
<?php 
$stmt->close();
$items_stmt->close();
include 'common/bottom.php'; 
?>