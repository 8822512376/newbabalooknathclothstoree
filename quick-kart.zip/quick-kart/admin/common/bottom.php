            </main>
        </div> <!-- End main content -->
    </div> <!-- End relative container -->

    <script>
        // --- UX ENHANCEMENTS ---
        document.addEventListener('contextmenu', event => event.preventDefault());
        document.addEventListener('gesturestart', function (e) { e.preventDefault(); });

        // --- GLOBAL LOADER ---
        const showLoader = () => document.getElementById('loader-overlay').classList.remove('hidden');
        const hideLoader = () => document.getElementById('loader-overlay').classList.add('hidden');

        // --- SIDEBAR LOGIC for mobile ---
        const menuBtn = document.getElementById('menu-btn');
        const closeBtn = document.getElementById('close-btn');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebar-overlay');
        
        if (menuBtn) { menuBtn.addEventListener('click', () => { sidebar.classList.remove('-translate-x-full'); overlay.classList.remove('hidden'); }); }
        if (closeBtn) { closeBtn.addEventListener('click', () => { sidebar.classList.add('-translate-x-full'); overlay.classList.add('hidden'); }); }
        if (overlay) { overlay.addEventListener('click', () => { sidebar.classList.add('-translate-x-full'); overlay.classList.add('hidden'); }); }

        // --- CORRECTED AJAX UTILITY ---
        async function sendAdminRequest(url, options) {
            showLoader();
            
            // This is the critical addition. We manually add the header PHP is expecting.
            const headers = new Headers();
            headers.append('X-Requested-With', 'XMLHttpRequest');

            const fetchOptions = {
                method: options.method || 'POST',
                headers: headers,
                body: options.body
            };

            try {
                const response = await fetch(url, fetchOptions);
                const rawResponseText = await response.text();

                if (!response.ok) {
                    throw new Error(`HTTP error ${response.status}: ${rawResponseText}`);
                }
                
                try {
                    const data = JSON.parse(rawResponseText);
                    hideLoader();
                    return data;
                } catch (jsonError) {
                    hideLoader();
                    // If the server sends an error instead of JSON, display it.
                    alert("SERVER ERROR:\n\n" + rawResponseText);
                    throw new Error("Invalid JSON from server.");
                }
            } catch (error) {
                console.error('AJAX Request Failed:', error);
                hideLoader();
                alert('A critical network error occurred. See browser console for details.');
                return { success: false, message: 'Network or client-side error.' };
            }
        }
    </script>
</body>
</html>