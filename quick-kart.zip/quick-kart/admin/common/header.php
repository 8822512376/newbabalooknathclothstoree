<?php
// Use a foolproof path to the config file.
require_once dirname(__DIR__, 2) . '/common/config.php';

// This check is critical. If not logged in, it stops everything.
if (!is_admin_logged_in() && basename($_SERVER['PHP_SELF']) !== 'login.php') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en" class="overflow-x-hidden">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Quick Kart - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        body, html { -webkit-user-select: none; user-select: none; -webkit-tap-highlight-color: transparent; overflow-x: hidden; background-color: #f1f5f9; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        #sidebar { transition: transform 0.3s ease-in-out; }
        #sidebar-overlay { transition: opacity 0.3s ease-in-out; }
        .loader-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); z-index: 9999; display: flex; align-items: center; justify-content: center; }
        .loader { width: 50px; aspect-ratio: 1; border-radius: 50%; border: 8px solid #0000; border-right-color: #4f46e5; position: relative; animation: l24 1s infinite linear; }
        .loader:before, .loader:after { content: ""; position: absolute; inset: -8px; border-radius: 50%; border: inherit; animation: inherit; animation-duration: 2s; }
        .loader:after { animation-duration: 4s; }
        @keyframes l24 { 100% {transform: rotate(1turn)} }
    </style>
</head>
<body class="antialiased">
    <div id="loader-overlay" class="loader-overlay hidden">
        <div class="loader"></div>
    </div>
    <div class="relative min-h-screen md:flex">
        <?php include 'sidebar.php'; ?>
        <div class="flex-1">
            <header class="bg-white shadow-sm sticky top-0 z-30 px-4 py-3 flex items-center justify-between">
                <button id="menu-btn" class="text-gray-700 text-xl md:hidden"><i class="fas fa-bars"></i></button>
                <h1 class="text-xl font-semibold text-gray-800">Dashboard</h1>
                <div class="flex items-center space-x-4">
                    <a href="setting.php" class="text-gray-600"><i class="fas fa-cog"></i></a>
                    <a href="login.php?logout=true" class="text-red-500"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            </header>
            <main class="p-4">