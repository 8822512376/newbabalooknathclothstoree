<!-- Sidebar Overlay -->
<div id="sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 hidden md:hidden"></div>
<!-- Sidebar -->
<aside id="sidebar" class="fixed top-0 left-0 w-64 h-full bg-slate-800 text-white z-50 transform -translate-x-full md:relative md:translate-x-0">
    <div class="p-5 border-b border-slate-700 flex justify-between items-center">
        <!-- UPDATED: Full store name -->
        <a href="index.php" class="text-lg font-bold leading-tight">New Baba LookNath Cloth Store</a>
        <button id="close-btn" class="text-gray-400 hover:text-white md:hidden">&times;</button>
    </div>
    <nav class="mt-4">
        <?php $current_page = basename($_SERVER['PHP_SELF']); ?>
        <a href="index.php" class="flex items-center px-5 py-3 hover:bg-slate-700 <?php echo $current_page == 'index.php' ? 'bg-slate-900' : ''; ?>"><i class="fas fa-tachometer-alt w-6"></i><span>Dashboard</span></a>
        <a href="category.php" class="flex items-center px-5 py-3 hover:bg-slate-700 <?php echo $current_page == 'category.php' ? 'bg-slate-900' : ''; ?>"><i class="fas fa-tags w-6"></i><span>Categories</span></a>
        <a href="product.php" class="flex items-center px-5 py-3 hover:bg-slate-700 <?php echo $current_page == 'product.php' ? 'bg-slate-900' : ''; ?>"><i class="fas fa-box-open w-6"></i><span>Products</span></a>
        <a href="order.php" class="flex items-center px-5 py-3 hover:bg-slate-700 <?php echo in_array($current_page, ['order.php', 'order_detail.php']) ? 'bg-slate-900' : ''; ?>"><i class="fas fa-receipt w-6"></i><span>Orders</span></a>
        <a href="user.php" class="flex items-center px-5 py-3 hover:bg-slate-700 <?php echo $current_page == 'user.php' ? 'bg-slate-900' : ''; ?>"><i class="fas fa-users w-6"></i><span>Users</span></a>
        <a href="setting.php" class="flex items-center px-5 py-3 hover:bg-slate-700 <?php echo $current_page == 'setting.php' ? 'bg-slate-900' : ''; ?>"><i class="fas fa-cogs w-6"></i><span>Settings</span></a>
    </nav>
</aside>