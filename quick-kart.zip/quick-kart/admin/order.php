<?php
include 'common/header.php';

$orders_result = $conn->query("
    SELECT o.id, u.name as user_name, o.total_amount, o.status, o.created_at 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    ORDER BY o.created_at DESC
");
?>
<div class="bg-white p-5 rounded-lg shadow-sm">
    <h2 class="text-xl font-semibold mb-4">All Orders</h2>
    <div class="overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                <tr>
                    <th class="px-6 py-3">Order ID</th>
                    <th class="px-6 py-3">User</th>
                    <th class="px-6 py-3">Amount</th>
                    <th class="px-6 py-3">Status</th>
                    <th class="px-6 py-3">Date</th>
                    <th class="px-6 py-3">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($order = $orders_result->fetch_assoc()): ?>
                <tr class="bg-white border-b hover:bg-gray-50">
                    <td class="px-6 py-4 font-bold">#<?php echo $order['id']; ?></td>
                    <td class="px-6 py-4"><?php echo htmlspecialchars($order['user_name']); ?></td>
                    <td class="px-6 py-4"><?php echo format_price($order['total_amount']); ?></td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 text-xs font-semibold rounded-full 
                        <?php 
                            switch($order['status']) {
                                case 'Placed': echo 'bg-blue-100 text-blue-800'; break;
                                case 'Dispatched': echo 'bg-yellow-100 text-yellow-800'; break;
                                case 'Delivered': echo 'bg-green-100 text-green-800'; break;
                                case 'Cancelled': echo 'bg-red-100 text-red-800'; break;
                            }
                        ?>">
                            <?php echo $order['status']; ?>
                        </span>
                    </td>
                    <td class="px-6 py-4"><?php echo date('d M, Y', strtotime($order['created_at'])); ?></td>
                    <td class="px-6 py-4">
                        <a href="order_detail.php?id=<?php echo $order['id']; ?>" class="font-medium text-indigo-600 hover:underline">View Details</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include 'common/bottom.php'; ?>