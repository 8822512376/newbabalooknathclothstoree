<?php
include 'common/header.php';

// --- FETCH DASHBOARD STATS ---
$total_users = $conn->query("SELECT COUNT(id) as count FROM users")->fetch_assoc()['count'];
$total_orders = $conn->query("SELECT COUNT(id) as count FROM orders")->fetch_assoc()['count'];
$total_revenue = $conn->query("SELECT SUM(total_amount) as sum FROM orders WHERE status = 'Delivered'")->fetch_assoc()['sum'];
$active_products = $conn->query("SELECT COUNT(id) as count FROM products WHERE stock > 0")->fetch_assoc()['count'];
$cancellations = $conn->query("SELECT COUNT(id) as count FROM orders WHERE status = 'Cancelled'")->fetch_assoc()['count'];
$pending_shipments = $conn->query("SELECT COUNT(id) as count FROM orders WHERE status = 'Placed'")->fetch_assoc()['count'];
?>

<!-- Stats Grid -->
<div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
    <!-- Total Users -->
    <div class="bg-white p-5 rounded-lg shadow-sm flex items-center space-x-4">
        <div class="p-3 rounded-full bg-blue-100 text-blue-600"><i class="fas fa-users fa-lg"></i></div>
        <div>
            <p class="text-sm text-gray-500">Total Users</p>
            <p class="text-2xl font-bold text-gray-800"><?php echo $total_users; ?></p>
        </div>
    </div>
    <!-- Total Orders -->
    <div class="bg-white p-5 rounded-lg shadow-sm flex items-center space-x-4">
        <div class="p-3 rounded-full bg-green-100 text-green-600"><i class="fas fa-receipt fa-lg"></i></div>
        <div>
            <p class="text-sm text-gray-500">Total Orders</p>
            <p class="text-2xl font-bold text-gray-800"><?php echo $total_orders; ?></p>
        </div>
    </div>
    <!-- Total Revenue -->
    <div class="bg-white p-5 rounded-lg shadow-sm flex items-center space-x-4">
        <div class="p-3 rounded-full bg-indigo-100 text-indigo-600"><i class="fas fa-wallet fa-lg"></i></div>
        <div>
            <p class="text-sm text-gray-500">Total Revenue</p>
            <p class="text-2xl font-bold text-gray-800"><?php echo format_price($total_revenue ?? 0); ?></p>
        </div>
    </div>
    <!-- Active Products -->
    <div class="bg-white p-5 rounded-lg shadow-sm flex items-center space-x-4">
        <div class="p-3 rounded-full bg-yellow-100 text-yellow-600"><i class="fas fa-box-open fa-lg"></i></div>
        <div>
            <p class="text-sm text-gray-500">Active Products</p>
            <p class="text-2xl font-bold text-gray-800"><?php echo $active_products; ?></p>
        </div>
    </div>
     <!-- Cancellations -->
    <div class="bg-white p-5 rounded-lg shadow-sm flex items-center space-x-4">
        <div class="p-3 rounded-full bg-red-100 text-red-600"><i class="fas fa-times-circle fa-lg"></i></div>
        <div>
            <p class="text-sm text-gray-500">Cancellations</p>
            <p class="text-2xl font-bold text-gray-800"><?php echo $cancellations; ?></p>
        </div>
    </div>
     <!-- Pending Shipments -->
    <div class="bg-white p-5 rounded-lg shadow-sm flex items-center space-x-4">
        <div class="p-3 rounded-full bg-orange-100 text-orange-600"><i class="fas fa-shipping-fast fa-lg"></i></div>
        <div>
            <p class="text-sm text-gray-500">Pending Shipments</p>
            <p class="text-2xl font-bold text-gray-800"><?php echo $pending_shipments; ?></p>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="mt-8">
    <h2 class="text-lg font-semibold text-gray-700 mb-3">Quick Actions</h2>
    <div class="flex flex-wrap gap-4">
        <a href="product.php" class="px-5 py-3 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 transition">
            <i class="fas fa-plus-circle mr-2"></i>Add Product
        </a>
        <a href="order.php" class="px-5 py-3 bg-slate-700 text-white font-semibold rounded-lg shadow-md hover:bg-slate-800 transition">
            <i class="fas fa-tasks mr-2"></i>Manage Orders
        </a>
        <a href="user.php" class="px-5 py-3 bg-slate-700 text-white font-semibold rounded-lg shadow-md hover:bg-slate-800 transition">
            <i class="fas fa-users-cog mr-2"></i>Manage Users
        </a>
    </div>
</div>

<?php include 'common/bottom.php'; ?>