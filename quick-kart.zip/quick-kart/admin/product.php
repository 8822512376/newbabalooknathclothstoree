<?php
// REMOVED session_name() from here.
require_once dirname(__DIR__) . '/common/config.php';

if (!is_admin_logged_in()) { header('HTTP/1.1 401 Unauthorized'); exit(); }

// --- AJAX CRUD HANDLER ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    header('Content-Type: application/json');
    $response = ['success' => false];
    $action = $_POST['action'] ?? '';
    $upload_dir = dirname(__DIR__) . '/uploads/';

    switch($action) {
        case 'create':
            $name = trim($_POST['name']);
            $cat_id = (int)$_POST['cat_id'];
            $price = (float)$_POST['price'];
            $stock = (int)$_POST['stock'];
            $desc = trim($_POST['description']);
            
            if (!empty($name) && $cat_id > 0 && isset($_FILES['image'])) {
                $image_name = time() . '_' . basename($_FILES['image']['name']);
                if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $image_name)) {
                    $stmt = $conn->prepare("INSERT INTO products (cat_id, name, description, price, stock, image) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("issdis", $cat_id, $name, $desc, $price, $stock, $image_name);
                    if ($stmt->execute()) {
                        $response = ['success' => true, 'message' => 'Product added successfully.'];
                    } else { $response['message'] = 'Database error.'; }
                } else { $response['message'] = 'Image upload failed.'; }
            } else { $response['message'] = 'All fields and image are required.'; }
            break;
        case 'delete':
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                 $stmt_select = $conn->prepare("SELECT image FROM products WHERE id = ?");
                 $stmt_select->bind_param("i", $id);
                 $stmt_select->execute();
                 $result = $stmt_select->get_result()->fetch_assoc();
                 if($result && !empty($result['image'])) @unlink($upload_dir . $result['image']);

                $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
                $stmt->bind_param("i", $id);
                if ($stmt->execute()) {
                    $response = ['success' => true];
                } else { $response['message'] = 'Failed to delete product.'; }
            }
            break;
    }
    echo json_encode($response);
    exit();
}

// --- Display Page ---
include 'common/header.php';
$products = $conn->query("SELECT p.id, p.name, p.price, p.stock, p.image, c.name as cat_name FROM products p JOIN categories c ON p.cat_id = c.id ORDER BY p.id DESC");
$categories = $conn->query("SELECT id, name FROM categories");
?>
<div class="bg-white p-5 rounded-lg shadow-sm">
    <h2 class="text-xl font-semibold mb-4">Add New Product</h2>
    <form id="add-product-form" class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <input type="hidden" name="action" value="create">
        <div>
            <label class="block text-sm font-medium">Product Name</label>
            <input type="text" name="name" class="mt-1 block w-full border-gray-300 rounded-md" required>
        </div>
        <div>
            <label class="block text-sm font-medium">Category</label>
            <select name="cat_id" class="mt-1 block w-full border-gray-300 rounded-md" required>
                <option value="">Select Category</option>
                <?php while($cat = $categories->fetch_assoc()): ?>
                <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium">Price (₹)</label>
            <input type="number" name="price" step="0.01" class="mt-1 block w-full border-gray-300 rounded-md" required>
        </div>
        <div>
            <label class="block text-sm font-medium">Stock Quantity</label>
            <input type="number" name="stock" class="mt-1 block w-full border-gray-300 rounded-md" required>
        </div>
        <div class="md:col-span-2">
            <label class="block text-sm font-medium">Description</label>
            <textarea name="description" rows="3" class="mt-1 block w-full border-gray-300 rounded-md"></textarea>
        </div>
        <div class="md:col-span-2">
            <label class="block text-sm font-medium">Product Image</label>
            <input type="file" name="image" accept="image/*" class="mt-1 block w-full" required>
        </div>
        <div class="md:col-span-2">
            <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Add Product</button>
        </div>
    </form>
</div>

<div class="mt-6 bg-white p-5 rounded-lg shadow-sm">
    <h2 class="text-xl font-semibold mb-4">Product List</h2>
    <div class="overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                <tr>
                    <th class="px-6 py-3">Product</th>
                    <th class="px-6 py-3">Category</th>
                    <th class="px-6 py-3">Price</th>
                    <th class="px-6 py-3">Stock</th>
                    <th class="px-6 py-3">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($prod = $products->fetch_assoc()): ?>
                <tr class="bg-white border-b" id="prod-row-<?php echo $prod['id']; ?>">
                    <td class="px-6 py-4 font-semibold flex items-center space-x-3">
                        <img src="../uploads/<?php echo $prod['image']; ?>" class="w-10 h-10 rounded-md object-cover">
                        <span><?php echo htmlspecialchars($prod['name']); ?></span>
                    </td>
                    <td class="px-6 py-4"><?php echo htmlspecialchars($prod['cat_name']); ?></td>
                    <td class="px-6 py-4"><?php echo format_price($prod['price']); ?></td>
                    <td class="px-6 py-4"><?php echo $prod['stock']; ?></td>
                    <td class="px-6 py-4">
                        <button onclick="deleteProduct(<?php echo $prod['id']; ?>)" class="font-medium text-red-600">Delete</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    document.getElementById('add-product-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        const result = await sendAdminRequest('product.php', { method: 'POST', body: new FormData(this) });
        if (result.success) {
            alert(result.message);
            location.reload();
        } else {
            alert(result.message || 'An error occurred.');
        }
    });

    async function deleteProduct(id) {
        if (!confirm('Are you sure?')) return;
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', id);
        const result = await sendAdminRequest('product.php', { method: 'POST', body: formData });
        if (result.success) {
            document.getElementById('prod-row-' + id).remove();
        } else {
            alert(result.message || 'Failed to delete.');
        }
    }
</script>

<?php include 'common/bottom.php'; ?>