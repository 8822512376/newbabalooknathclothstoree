<?php
include 'common/header.php';

$message = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_pass = $_POST['current_password'];
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];
    $admin_id = $_SESSION['admin_id'];

    $stmt = $conn->prepare("SELECT password FROM admin WHERE id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if ($result && password_verify($current_pass, $result['password'])) {
        if (!empty($new_pass) && $new_pass === $confirm_pass) {
            $hashed_pass = password_hash($new_pass, PASSWORD_DEFAULT);
            $update_stmt = $conn->prepare("UPDATE admin SET password = ? WHERE id = ?");
            $update_stmt->bind_param("si", $hashed_pass, $admin_id);
            if ($update_stmt->execute()) {
                $message = "Password changed successfully!";
                $success = true;
            } else {
                $message = "Failed to change password.";
            }
        } else {
            $message = "New passwords do not match or are empty.";
        }
    } else {
        $message = "Incorrect current password.";
    }
}
?>
<div class="max-w-xl mx-auto">
    <div class="bg-white p-6 rounded-lg shadow-sm">
        <h2 class="text-xl font-semibold mb-4">Admin Settings</h2>

        <?php if ($message): ?>
        <div class="p-3 mb-4 rounded-md text-center <?php echo $success ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
            <?php echo $message; ?>
        </div>
        <?php endif; ?>

        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-sm font-medium">Username</label>
                <input type="text" value="<?php echo htmlspecialchars($_SESSION['admin_username']); ?>" class="w-full mt-1 p-2 border rounded-md bg-gray-100" readonly>
            </div>
            <div>
                <label class="block text-sm font-medium">Current Password</label>
                <input type="password" name="current_password" class="w-full mt-1 p-2 border rounded-md" required>
            </div>
            <div>
                <label class="block text-sm font-medium">New Password</label>
                <input type="password" name="new_password" class="w-full mt-1 p-2 border rounded-md" required>
            </div>
            <div>
                <label class="block text-sm font-medium">Confirm New Password</label>
                <input type="password" name="confirm_password" class="w-full mt-1 p-2 border rounded-md" required>
            </div>
            <button type="submit" name="change_password" class="w-full py-2 font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-700">Change Password</button>
        </form>
    </div>
</div>

<?php include 'common/bottom.php'; ?>