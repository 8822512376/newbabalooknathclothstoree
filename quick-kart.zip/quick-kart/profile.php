<?php
include 'common/header.php';

if (!is_user_logged_in()) {
    header("Location: login.php");
    exit();
}

$user_id = get_user_id();
$message = '';
$success = false;

// --- HANDLE FORM SUBMISSIONS ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $name = trim($_POST['name']);
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address']);
        
        $stmt = $conn->prepare("UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?");
        $stmt->bind_param("sssi", $name, $phone, $address, $user_id);
        if ($stmt->execute()) {
            $message = "Profile updated successfully!";
            $success = true;
        } else {
            $message = "Failed to update profile.";
        }
        $stmt->close();
    }
    
    if (isset($_POST['change_password'])) {
        $current_pass = $_POST['current_password'];
        $new_pass = $_POST['new_password'];
        $confirm_pass = $_POST['confirm_password'];

        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();

        if ($result && password_verify($current_pass, $result['password'])) {
            if ($new_pass === $confirm_pass) {
                $hashed_pass = password_hash($new_pass, PASSWORD_DEFAULT);
                $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                $update_stmt->bind_param("si", $hashed_pass, $user_id);
                if ($update_stmt->execute()) {
                    $message = "Password changed successfully!";
                    $success = true;
                } else {
                    $message = "Failed to change password.";
                }
            } else {
                $message = "New passwords do not match.";
            }
        } else {
            $message = "Incorrect current password.";
        }
    }
}


// Fetch current user data
$stmt = $conn->prepare("SELECT name, email, phone, address FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
?>

<main class="p-4">
    <h1 class="text-2xl font-bold text-gray-800 mb-4">My Profile</h1>

    <?php if ($message): ?>
    <div class="p-3 mb-4 rounded-md text-center <?php echo $success ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
        <?php echo $message; ?>
    </div>
    <?php endif; ?>

    <!-- Edit Profile Form -->
    <div class="bg-white rounded-lg shadow-sm p-4">
        <h2 class="text-lg font-semibold mb-3">Edit Information</h2>
        <form method="POST" class="space-y-4">
            <div>
                <label class="text-sm font-medium">Name</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" class="w-full mt-1 p-2 border rounded-md">
            </div>
            <div>
                <label class="text-sm font-medium">Email</label>
                <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" class="w-full mt-1 p-2 border rounded-md bg-gray-100" readonly>
            </div>
            <div>
                <label class="text-sm font-medium">Phone</label>
                <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" class="w-full mt-1 p-2 border rounded-md">
            </div>
             <div>
                <label class="text-sm font-medium">Address</label>
                <textarea name="address" rows="3" class="w-full mt-1 p-2 border rounded-md"><?php echo htmlspecialchars($user['address']); ?></textarea>
            </div>
            <button type="submit" name="update_profile" class="w-full py-2 font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-700">Update Profile</button>
        </form>
    </div>

    <!-- Change Password Form -->
    <div class="bg-white rounded-lg shadow-sm p-4 mt-4">
        <h2 class="text-lg font-semibold mb-3">Change Password</h2>
        <form method="POST" class="space-y-4">
            <div>
                <input type="password" name="current_password" placeholder="Current Password" class="w-full p-2 border rounded-md" required>
            </div>
            <div>
                <input type="password" name="new_password" placeholder="New Password" class="w-full p-2 border rounded-md" required>
            </div>
            <div>
                <input type="password" name="confirm_password" placeholder="Confirm New Password" class="w-full p-2 border rounded-md" required>
            </div>
            <button type="submit" name="change_password" class="w-full py-2 font-semibold text-white bg-gray-700 rounded-md hover:bg-gray-800">Change Password</button>
        </form>
    </div>
    
    <div class="mt-6 text-center">
         <a href="login.php?logout=true" class="px-8 py-3 font-semibold text-red-600 bg-red-100 rounded-lg hover:bg-red-200 transition">
            <i class="fas fa-sign-out-alt mr-2"></i>Logout
        </a>
    </div>
</main>

<?php 
$stmt->close();
include 'common/bottom.php'; 
?>