<?php
require_once __DIR__ . '/common/config.php';
// (The rest of the PHP logic is the same)
if (isset($_GET['logout'])) { session_destroy(); header("Location: login.php"); exit(); }
if (is_user_logged_in()) { header("Location: index.php"); exit(); }
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    header('Content-Type: application/json'); $response = ['success' => false, 'message' => 'An unknown error occurred.']; $action = $_POST['action'] ?? '';
    if ($action === 'signup') {
        $name = trim($_POST['name'] ?? ''); $phone = trim($_POST['phone'] ?? ''); $email = trim($_POST['email'] ?? ''); $password = $_POST['password'] ?? '';
        if (empty($name) || empty($phone) || empty($email) || empty($password)) { $response['message'] = 'All fields are required.'; } 
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $response['message'] = 'Invalid email format.'; } 
        else {
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR phone = ?"); $stmt->bind_param("ss", $email, $phone); $stmt->execute(); $stmt->store_result();
            if ($stmt->num_rows > 0) { $response['message'] = 'Email or Phone number already registered.'; } 
            else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt_insert = $conn->prepare("INSERT INTO users (name, phone, email, password) VALUES (?, ?, ?, ?)");
                $stmt_insert->bind_param("ssss", $name, $phone, $email, $hashed_password);
                if ($stmt_insert->execute()) { $response = ['success' => true, 'message' => 'Signup successful! Please login.']; } else { $response['message'] = 'Signup failed. Please try again.'; }
                $stmt_insert->close();
            } $stmt->close();
        }
    } elseif ($action === 'login') {
        $email = trim($_POST['email'] ?? ''); $password = $_POST['password'] ?? '';
        if (empty($email) || empty($password)) { $response['message'] = 'Email and password are required.'; } 
        else {
            $stmt = $conn->prepare("SELECT id, password FROM users WHERE email = ?"); $stmt->bind_param("s", $email); $stmt->execute(); $stmt->store_result();
            if ($stmt->num_rows === 1) {
                $stmt->bind_result($user_id, $hashed_password); $stmt->fetch();
                if (password_verify($password, $hashed_password)) {
                    $_SESSION['user_id'] = $user_id; $_SESSION['user_email'] = $email;
                    $response = ['success' => true, 'redirect' => 'index.php'];
                } else { $response['message'] = 'Invalid email or password.'; }
            } else { $response['message'] = 'Invalid email or password.'; }
            $stmt->close();
        }
    }
    echo json_encode($response); if (isset($conn)) { $conn->close(); } exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Login - New Baba LookNath Cloth Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style> body { -webkit-user-select: none; user-select: none; } .tab-button.active { border-bottom-color: #4f46e5; color: #4f46e5; } .tab-content { display: none; } .tab-content.active { display: block; } </style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div id="loader-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden items-center justify-center"><div class="loader w-12 h-12 border-4 border-t-indigo-500 border-gray-200 rounded-full animate-spin"></div></div>
    <div class="w-full max-w-sm p-6 bg-white rounded-lg shadow-xl">
        <div class="text-center mb-8">
            <h1 class="text-2xl font-bold text-indigo-600">New Baba LookNath Cloth Store</h1>
        </div>
        <div class="flex border-b mb-6">
            <button id="login-tab-btn" class="tab-button flex-1 py-2 text-lg font-semibold border-b-2 transition active">Login</button>
            <button id="signup-tab-btn" class="tab-button flex-1 py-2 text-lg font-semibold border-b-2 text-gray-500 transition">Sign Up</button>
        </div>
        <div id="message-area" class="p-3 mb-4 rounded-md text-center hidden"></div>
        <div id="login-tab-content" class="tab-content active">
            <form id="login-form" class="space-y-4"><input type="hidden" name="action" value="login"><div><input type="email" name="email" placeholder="Email Address" class="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" required></div><div><input type="password" name="password" placeholder="Password" class="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" required></div><button type="submit" class="w-full py-3 font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 transition">Login</button></form>
        </div>
        <div id="signup-tab-content" class="tab-content">
            <form id="signup-form" class="space-y-4"><input type="hidden" name="action" value="signup"><div><input type="text" name="name" placeholder="Full Name" class="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" required></div><div><input type="tel" name="phone" placeholder="Phone Number" class="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" required></div><div><input type="email" name="email" placeholder="Email Address" class="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" required></div><div><input type="password" name="password" placeholder="Create Password" class="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500" required></div><button type="submit" class="w-full py-3 font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 transition">Create Account</button></form>
        </div>
    </div>
    <script>
        // (JavaScript logic remains the same)
        document.addEventListener('contextmenu', event => event.preventDefault()); const loginTabBtn = document.getElementById('login-tab-btn'); const signupTabBtn = document.getElementById('signup-tab-btn'); const loginTabContent = document.getElementById('login-tab-content'); const signupTabContent = document.getElementById('signup-tab-content'); const messageArea = document.getElementById('message-area'); const loader = document.getElementById('loader-overlay'); function showMessage(message, isSuccess) { messageArea.textContent = message; messageArea.className = `p-3 mb-4 rounded-md text-center ${isSuccess ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`; messageArea.classList.remove('hidden'); }
        loginTabBtn.addEventListener('click', () => { loginTabBtn.classList.add('active'); signupTabBtn.classList.remove('active'); loginTabContent.classList.add('active'); signupTabContent.classList.remove('active'); messageArea.classList.add('hidden'); });
        signupTabBtn.addEventListener('click', () => { signupTabBtn.classList.add('active'); loginTabBtn.classList.remove('active'); signupTabContent.classList.add('active'); loginTabContent.classList.remove('active'); messageArea.classList.add('hidden'); });
        async function handleFormSubmit(event) {
            event.preventDefault(); loader.style.display = 'flex'; const form = event.target; const formData = new FormData(form);
            try {
                const response = await fetch('login.php', { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' }, body: formData }); const result = await response.json();
                showMessage(result.message, result.success);
                if (result.success) { if(result.redirect) { setTimeout(() => { window.location.href = result.redirect; }, 1000); } else { loginTabBtn.click(); document.getElementById('login-form').reset(); } }
            } catch (error) { showMessage('An error occurred. Please try again.', false); console.error('Error:', error); } finally { loader.style.display = 'none'; }
        }
        document.getElementById('login-form').addEventListener('submit', handleFormSubmit); document.getElementById('signup-form').addEventListener('submit', handleFormSubmit);
    </script>
</body>
</html>