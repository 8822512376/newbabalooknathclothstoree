<?php
include 'common/header.php';

if (!is_user_logged_in()) {
    header("Location: login.php");
    exit();
}

// Fetch categories
$categories_result = $conn->query("SELECT id, name, image FROM categories LIMIT 8");

// Fetch featured products
$products_result = $conn->query("SELECT id, name, price, image FROM products ORDER BY created_at DESC LIMIT 10");
?>

<main class="p-4">
    <!-- Categories Section -->
    <section class="mb-6">
        <h2 class="text-xl font-bold text-gray-800 mb-3">Categories</h2>
        <div class="flex space-x-4 overflow-x-auto pb-2 no-scrollbar">
            <?php while($cat = $categories_result->fetch_assoc()): ?>
            <a href="product.php?cat_id=<?php echo $cat['id']; ?>" class="flex-shrink-0 text-center">
                <div class="w-16 h-16 bg-white rounded-full shadow-md flex items-center justify-center overflow-hidden">
                    <img src="uploads/<?php echo htmlspecialchars($cat['image']); ?>" alt="<?php echo htmlspecialchars($cat['name']); ?>" class="w-full h-full object-cover">
                </div>
                <span class="text-xs mt-2 block text-gray-600"><?php echo htmlspecialchars($cat['name']); ?></span>
            </a>
            <?php endwhile; ?>
        </div>
    </section>

    <!-- Featured Products Section -->
    <section>
        <h2 class="text-xl font-bold text-gray-800 mb-3">Featured Products</h2>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            <?php while($product = $products_result->fetch_assoc()): ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <a href="product_detail.php?id=<?php echo $product['id']; ?>">
                    <img src="uploads/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="w-full h-32 object-cover">
                </a>
                <div class="p-3">
                    <h3 class="text-sm font-semibold text-gray-800 truncate"><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p class="text-md font-bold text-indigo-600 mt-1"><?php echo format_price($product['price']); ?></p>
                    <button class="w-full mt-2 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-500 rounded-md hover:bg-indigo-600 transition">
                        Add to Cart
                    </button>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </section>
</main>

<?php include 'common/bottom.php'; ?>