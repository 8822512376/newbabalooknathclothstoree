<?php
include 'common/header.php';

if (!is_user_logged_in()) {
    header("Location: login.php");
    exit();
}

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($product_id === 0) {
    echo "<p>Product not found.</p>";
    include 'common/bottom.php';
    exit();
}

// Fetch product details
$stmt = $conn->prepare("SELECT p.id, p.name, p.description, p.price, p.stock, p.image, c.name as category_name FROM products p JOIN categories c ON p.cat_id = c.id WHERE p.id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
    echo "<p class='text-center p-4'>Product not found.</p>";
    include 'common/bottom.php';
    exit();
}

// Fetch related products
$related_stmt = $conn->prepare("SELECT id, name, price, image FROM products WHERE cat_id = (SELECT cat_id FROM products WHERE id=?) AND id != ? LIMIT 4");
$related_stmt->bind_param("ii", $product_id, $product_id);
$related_stmt->execute();
$related_products_result = $related_stmt->get_result();
?>

<main>
    <!-- Product Image Slider -->
    <div class="relative bg-white">
        <img src="uploads/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="w-full h-64 object-cover">
    </div>

    <!-- Product Details -->
    <div class="p-4 bg-white">
        <h1 class="text-2xl font-bold text-gray-800"><?php echo htmlspecialchars($product['name']); ?></h1>
        <p class="text-gray-500 text-sm mt-1"><?php echo htmlspecialchars($product['category_name']); ?></p>
        <div class="flex justify-between items-center mt-4">
            <span class="text-3xl font-bold text-indigo-600"><?php echo format_price($product['price']); ?></span>
            <span class="px-3 py-1 text-sm font-semibold rounded-full <?php echo $product['stock'] > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                <?php echo $product['stock'] > 0 ? 'In Stock' : 'Out of Stock'; ?>
            </span>
        </div>
    </div>

    <!-- Add to Cart Section -->
    <div class="p-4 mt-2 bg-white flex items-center space-x-4">
        <div class="flex items-center border rounded-md">
            <button id="qty-minus" class="px-3 py-2 text-lg text-gray-600">-</button>
            <input id="quantity" type="text" value="1" readonly class="w-12 text-center border-l border-r">
            <button id="qty-plus" class="px-3 py-2 text-lg text-gray-600">+</button>
        </div>
        <button id="add-to-cart-btn" class="flex-1 py-3 text-lg font-semibold text-white bg-indigo-600 rounded-lg shadow-md hover:bg-indigo-700 transition">
            Add to Cart
        </button>
    </div>

    <!-- Description -->
    <div class="p-4 mt-2 bg-white">
        <h2 class="text-lg font-semibold text-gray-800 mb-2">Description</h2>
        <p class="text-gray-600 text-sm leading-relaxed">
            <?php echo nl2br(htmlspecialchars($product['description'])); ?>
        </p>
    </div>

    <!-- Related Products -->
    <?php if ($related_products_result->num_rows > 0): ?>
    <section class="p-4 mt-2 bg-white">
        <h2 class="text-lg font-semibold text-gray-800 mb-3">Related Products</h2>
        <div class="grid grid-cols-2 gap-4">
            <?php while($related_product = $related_products_result->fetch_assoc()): ?>
            <div class="rounded-lg overflow-hidden border">
                <a href="product_detail.php?id=<?php echo $related_product['id']; ?>">
                    <img src="uploads/<?php echo htmlspecialchars($related_product['image']); ?>" alt="<?php echo htmlspecialchars($related_product['name']); ?>" class="w-full h-24 object-cover">
                </a>
                <div class="p-2">
                    <h3 class="text-xs font-semibold text-gray-800 truncate"><?php echo htmlspecialchars($related_product['name']); ?></h3>
                    <p class="text-sm font-bold text-indigo-600 mt-1"><?php echo format_price($related_product['price']); ?></p>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </section>
    <?php endif; ?>
</main>

<script>
    const qtyInput = document.getElementById('quantity');
    const stock = <?php echo $product['stock']; ?>;

    document.getElementById('qty-plus').addEventListener('click', () => {
        let currentQty = parseInt(qtyInput.value);
        if (currentQty < stock) {
            qtyInput.value = currentQty + 1;
        }
    });

    document.getElementById('qty-minus').addEventListener('click', () => {
        let currentQty = parseInt(qtyInput.value);
        if (currentQty > 1) {
            qtyInput.value = currentQty - 1;
        }
    });
    
    document.getElementById('add-to-cart-btn').addEventListener('click', async () => {
        const productId = <?php echo $product_id; ?>;
        const quantity = parseInt(qtyInput.value);

        const formData = new FormData();
        formData.append('action', 'add');
        formData.append('product_id', productId);
        formData.append('quantity', quantity);

        const result = await sendRequest('cart.php', {
            method: 'POST',
            body: formData
        });

        if (result.success) {
            alert(result.message); // Replace with a nicer notification later
        } else {
            alert(result.message || 'Could not add to cart.');
        }
    });
</script>

<?php
$stmt->close();
$related_stmt->close();
include 'common/bottom.php';
?>