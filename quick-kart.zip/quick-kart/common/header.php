<?php
require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="en" class="overflow-x-hidden">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>New Baba LookNath Cloth Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        body, html { -webkit-user-select: none; user-select: none; -webkit-tap-highlight-color: transparent; overflow-x: hidden; background-color: #f7f8fa; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        #sidebar { transition: transform 0.3s ease-in-out; }
        #sidebar-overlay { transition: opacity 0.3s ease-in-out; }
        .loader-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); z-index: 9999; display: flex; align-items: center; justify-content: center; }
        .loader { width: 50px; aspect-ratio: 1; border-radius: 50%; border: 8px solid #0000; border-right-color: #4f46e5; position: relative; animation: l24 1s infinite linear; }
        .loader:before, .loader:after { content: ""; position: absolute; inset: -8px; border-radius: 50%; border: inherit; animation: inherit; animation-duration: 2s; }
        .loader:after { animation-duration: 4s; }
        @keyframes l24 { 100% {transform: rotate(1turn)} }
        #search-form { display: none; }
    </style>
</head>
<body class="antialiased">
    <div id="loader-overlay" class="loader-overlay hidden">
        <div class="loader"></div>
    </div>
    <div class="relative min-h-screen pb-20">
        <header class="bg-white shadow-sm sticky top-0 z-40 px-4 py-3">
            <div class="flex items-center justify-between">
                <button id="menu-btn" class="text-gray-700 text-xl"><i class="fas fa-bars"></i></button>
                <!-- UPDATED: Full store name with adjusted text size -->
                <a href="index.php" class="text-lg font-bold text-indigo-600 text-center">New Baba LookNath Cloth Store</a>
                <div class="flex items-center space-x-4">
                    <button id="search-icon" class="text-gray-700 text-xl"><i class="fas fa-search"></i></button>
                    <a href="order.php" class="text-gray-700 text-xl"><i class="fas fa-bell"></i></a>
                </div>
            </div>
            <form id="search-form" action="product.php" method="GET" class="mt-3">
                <div class="relative">
                    <input type="search" name="search" placeholder="Search for products..." class="w-full pl-4 pr-10 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <button type="submit" class="absolute right-0 top-0 mt-2 mr-3 text-gray-500"><i class="fas fa-search"></i></button>
                </div>
            </form>
        </header>
        <?php include 'sidebar.php'; ?>
        <main>