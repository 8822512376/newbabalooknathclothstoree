<?php
if (session_status() === PHP_SESSION_NONE) {
    if (strpos($_SERVER['REQUEST_URI'], '/admin/') !== false) {
        session_name('admin_session');
    } else {
        session_name('user_session');
    }
    session_start();
}

// --- DATABASE CREDENTIALS ---
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'Newbabalooknathclothstore'); // <-- UPDATED NAME

// --- ESTABLISH DATABASE CONNECTION ---
@$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    if ($conn->connect_errno === 1049 && basename($_SERVER['PHP_SELF']) !== 'install.php') {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
        $host = $_SERVER['HTTP_HOST'];
        $script_path = preg_replace('/(admin\/)?\w+\.php$/', '', $_SERVER['REQUEST_URI']);
        $installer_url = $protocol . $host . $script_path . 'install.php';
        header("Location: " . $installer_url);
        exit();
    }
    die("Database connection failed: " . $conn->connect_error);
}

// --- HELPER FUNCTIONS ---
function get_user_id() {
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
}
function is_user_logged_in() {
    return isset($_SESSION['user_id']);
}
function is_admin_logged_in() {
    return isset($_SESSION['admin_id']);
}
function format_price($price) {
    return '₹' . number_format($price, 2);
}