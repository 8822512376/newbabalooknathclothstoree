        </main> <!-- End main content area -->
    </div> <!-- End relative container -->

    <!-- Bottom Navigation -->
    <nav class="fixed bottom-0 left-0 right-0 bg-white shadow-lg border-t z-40 flex justify-around">
        <a href="index.php" class="flex flex-col items-center justify-center w-full pt-2 pb-1 text-indigo-600"><i class="fas fa-home text-xl"></i><span class="text-xs font-medium">Home</span></a>
        <a href="order.php" class="flex flex-col items-center justify-center w-full pt-2 pb-1 text-gray-500 hover:text-indigo-600"><i class="fas fa-box text-xl"></i><span class="text-xs">Orders</span></a>
        <a href="cart.php" class="flex flex-col items-center justify-center w-full pt-2 pb-1 text-gray-500 hover:text-indigo-600"><i class="fas fa-shopping-cart text-xl"></i><span class="text-xs">Cart</span></a>
        <a href="profile.php" class="flex flex-col items-center justify-center w-full pt-2 pb-1 text-gray-500 hover:text-indigo-600"><i class="fas fa-user text-xl"></i><span class="text-xs">Profile</span></a>
    </nav>
    
    <!-- Location Modal (NEW) -->
    <div id="location-modal-overlay" class="fixed inset-0 bg-black bg-opacity-60 z-50 hidden flex items-center justify-center p-4">
        <div id="location-modal" class="bg-white rounded-lg shadow-xl p-4 text-center w-full max-w-lg transform scale-95 opacity-0 transition-all duration-300">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Our Store Location</h2>
            <div class="aspect-w-16 aspect-h-9">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3579.974342596269!2d92.3118935!3d26.1975129!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x375acfa7b0d434cf%3A0xee0d002e2669c110!2sBaba%20Loknath%20Cloth%20And%20Store!5e0!3m2!1sen!2sin!4v1755465037276!5m2!1sen!2sin" class="w-full h-64 rounded-lg" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            <button id="close-location-modal-btn" class="mt-4 w-full py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">Close</button>
        </div>
    </div>

    <script>
        // --- UX ENHANCEMENTS ---
        document.addEventListener('contextmenu', event => event.preventDefault());
        document.addEventListener('gesturestart', function (e) { e.preventDefault(); });
        document.addEventListener('touchmove', function(event) { if (event.scale !== 1 && event.scale !== undefined) { event.preventDefault(); } }, { passive: false });

        // --- GLOBAL LOADER ---
        const showLoader = () => document.getElementById('loader-overlay').classList.remove('hidden');
        const hideLoader = () => document.getElementById('loader-overlay').classList.add('hidden');

        // --- SIDEBAR LOGIC ---
        const menuBtn = document.getElementById('menu-btn');
        const closeBtn = document.getElementById('close-btn');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebar-overlay');
        if (menuBtn) { menuBtn.addEventListener('click', () => { sidebar.classList.remove('-translate-x-full'); overlay.classList.remove('hidden'); }); }
        if (closeBtn) { closeBtn.addEventListener('click', () => { sidebar.classList.add('-translate-x-full'); overlay.classList.add('hidden'); }); }
        if (overlay) { overlay.addEventListener('click', () => { sidebar.classList.add('-translate-x-full'); overlay.classList.add('hidden'); }); }

        // --- SEARCH BAR TOGGLE LOGIC ---
        const searchIcon = document.getElementById('search-icon');
        const searchForm = document.getElementById('search-form');
        if (searchIcon && searchForm) {
            searchIcon.addEventListener('click', () => {
                if (searchForm.style.display === 'none' || searchForm.style.display === '') {
                    searchForm.style.display = 'block';
                } else {
                    searchForm.style.display = 'none';
                }
            });
        }

        // --- LOCATION MODAL LOGIC (NEW) ---
        const locationBtn = document.getElementById('location-btn');
        const locationModalOverlay = document.getElementById('location-modal-overlay');
        const locationModal = document.getElementById('location-modal');
        const closeLocationModalBtn = document.getElementById('close-location-modal-btn');
        function showLocationModal() {
            locationModalOverlay.classList.remove('hidden');
            setTimeout(() => { locationModal.classList.remove('scale-95', 'opacity-0'); locationModal.classList.add('scale-100', 'opacity-100'); }, 50);
        }
        function hideLocationModal() {
            locationModal.classList.add('scale-95', 'opacity-0');
            setTimeout(() => { locationModalOverlay.classList.add('hidden'); }, 300);
        }
        if (locationBtn) { locationBtn.addEventListener('click', showLocationModal); }
        if (closeLocationModalBtn) { closeLocationModalBtn.addEventListener('click', hideLocationModal); }
        if (locationModalOverlay) { locationModalOverlay.addEventListener('click', function(event) { if (event.target === locationModalOverlay) { hideLocationModal(); } }); }
        
        // --- AJAX UTILITY ---
        async function sendRequest(url, options = {}) { /* ... same as before ... */ }
    </script>
</body>
</html>