<!-- Sidebar Overlay -->
<div id="sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 hidden"></div>

<!-- Sidebar -->
<aside id="sidebar" class="fixed top-0 left-0 w-64 h-full bg-white shadow-lg z-50 transform -translate-x-full flex flex-col">
    <div class="p-5 border-b flex justify-between items-center">
        <h2 class="text-xl font-bold text-indigo-600">Menu</h2>
        <button id="close-btn" class="text-gray-600 hover:text-gray-800 text-2xl">&times;</button>
    </div>
    
    <!-- Main Navigation -->
    <nav class="mt-4">
        <a href="index.php" class="flex items-center px-5 py-3 text-gray-700 hover:bg-gray-100"><i class="fas fa-home w-6 text-gray-500"></i><span>Home</span></a>
        <a href="order.php" class="flex items-center px-5 py-3 text-gray-700 hover:bg-gray-100"><i class="fas fa-box w-6 text-gray-500"></i><span>My Orders</span></a>
        <a href="cart.php" class="flex items-center px-5 py-3 text-gray-700 hover:bg-gray-100"><i class="fas fa-shopping-cart w-6 text-gray-500"></i><span>My Cart</span></a>
        <a href="profile.php" class="flex items-center px-5 py-3 text-gray-700 hover:bg-gray-100"><i class="fas fa-user w-6 text-gray-500"></i><span>My Profile</span></a>
        
        <!-- NEW LOCATION LINK -->
        <a href="#" id="location-btn" class="flex items-center px-5 py-3 text-gray-700 hover:bg-gray-100">
            <i class="fas fa-map-marker-alt w-6 text-gray-500"></i>
            <span>Our Location</span>
        </a>
        <hr class="my-2">
    </nav>

    <!-- Social Media Section -->
    <div class="mt-4 px-5">
        <h3 class="text-sm font-semibold text-gray-400 uppercase tracking-wider">Follow Us</h3>
        <nav class="mt-3 space-y-1">
            <a href="https://www.facebook.com/newbabalooknathclothstore" target="_blank" class="flex items-center p-2 text-gray-700 hover:bg-gray-100 rounded-lg"><i class="fab fa-facebook-f w-6 text-blue-600"></i><span>Facebook</span></a>
            <a href="https://www.instagram.com/newbabalooknathclothstore?igsh=Z2p4Y3hsNHprbHVu" target="_blank" class="flex items-center p-2 text-gray-700 hover:bg-gray-100 rounded-lg"><i class="fab fa-instagram w-6 text-pink-500"></i><span>Instagram</span></a>
            <a href="https://wa.me/918822512376" target="_blank" class="flex items-center p-2 text-gray-700 hover:bg-gray-100 rounded-lg"><i class="fab fa-whatsapp w-6 text-green-500"></i><span>WhatsApp</span></a>
        </nav>
    </div>

    <!-- Logout Button at the bottom -->
    <div class="mt-auto p-5">
        <?php if(is_user_logged_in()): ?>
            <a href="login.php?logout=true" class="flex items-center justify-center w-full px-4 py-2 text-red-600 bg-red-50 hover:bg-red-100 rounded-lg"><i class="fas fa-sign-out-alt w-6 mr-2"></i><span>Logout</span></a>
        <?php else: ?>
            <a href="login.php" class="flex items-center justify-center w-full px-4 py-2 text-green-700 bg-green-50 hover:bg-green-100 rounded-lg"><i class="fas fa-sign-in-alt w-6 mr-2"></i><span>Login</span></a>
        <?php endif; ?>
    </div>
</aside>