<?php
// This new installer connects directly using your config and only creates tables.
require_once __DIR__ . '/common/config.php';

$message = "";
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['install'])) {
    try {
        // The connection is already made by config.php
        global $conn;

        $sql_schema = "CREATE TABLE IF NOT EXISTS `users` (`id` INT AUTO_INCREMENT PRIMARY KEY,`name` VARCHAR(100) NOT NULL,`phone` VARCHAR(15) NOT NULL UNIQUE,`email` VARCHAR(100) NOT NULL UNIQUE,`password` VARCHAR(255) NOT NULL,`address` TEXT,`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP); CREATE TABLE IF NOT EXISTS `admin` (`id` INT AUTO_INCREMENT PRIMARY KEY,`username` VARCHAR(50) NOT NULL UNIQUE,`password` VARCHAR(255) NOT NULL); CREATE TABLE IF NOT EXISTS `categories` (`id` INT AUTO_INCREMENT PRIMARY KEY,`name` VARCHAR(100) NOT NULL,`image` VARCHAR(255)); CREATE TABLE IF NOT EXISTS `products` (`id` INT AUTO_INCREMENT PRIMARY KEY,`cat_id` INT NOT NULL,`name` VARCHAR(255) NOT NULL,`description` TEXT,`price` DECIMAL(10, 2) NOT NULL,`stock` INT NOT NULL DEFAULT 0,`image` VARCHAR(255),`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY (`cat_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE); CREATE TABLE IF NOT EXISTS `orders` (`id` INT AUTO_INCREMENT PRIMARY KEY,`user_id` INT NOT NULL,`total_amount` DECIMAL(10, 2) NOT NULL,`shipping_address` TEXT NOT NULL,`status` VARCHAR(50) DEFAULT 'Placed',`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE); CREATE TABLE IF NOT EXISTS `order_items` (`id` INT AUTO_INCREMENT PRIMARY KEY,`order_id` INT NOT NULL,`product_id` INT NOT NULL,`quantity` INT NOT NULL,`price` DECIMAL(10, 2) NOT NULL,FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE);";
        
        if (!$conn->multi_query($sql_schema)) { throw new Exception("Error creating tables: " . $conn->error); }
        while ($conn->next_result()) {;} // Clear results from multi_query

        $admin_user = 'admin';
        $admin_pass = password_hash('admin123', PASSWORD_DEFAULT);
        $sql_admin = "INSERT INTO `admin` (`username`, `password`) VALUES ('$admin_user', '$admin_pass') ON DUPLICATE KEY UPDATE `password`='$admin_pass'";
        $conn->query($sql_admin);

        $upload_dir = 'uploads';
        if (!is_dir($upload_dir)) { mkdir($upload_dir, 0777, true); }

        $message = "Tables created successfully! Redirecting to login...";
        $success = true;
        header("Refresh: 3; url=login.php");

    } catch (Exception $e) {
        $message = "An error occurred: " . $e->getMessage();
        $success = false;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installer - New Baba LookNath Cloth Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-md">
        <div class="text-center">
            <h1 class="text-2xl font-bold text-gray-800">New Baba LookNath Cloth Store</h1>
            <p class="text-gray-500">Table Installer for Live Hosting</p>
        </div>
        <?php if (!empty($message)): ?><div class="p-4 rounded-md <?php echo $success ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>"><?php echo $message; ?></div><?php endif; ?>
        <p class="text-center text-sm text-gray-600">This will install the required tables into your existing database on <strong><?php echo DB_HOST; ?></strong>.</p>
        <form method="POST"><button type="submit" name="install" class="w-full px-4 py-2 text-lg font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-700">Install Tables Now</button></form>
    </div>
</body>
</html>