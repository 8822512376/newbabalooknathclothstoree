<?php
require_once 'common/config.php';

// Ensure user is logged in for any cart action
if (!is_user_logged_in()) {
    // If it's an AJAX request, send an error. Otherwise, redirect.
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Please login to manage your cart.', 'redirect' => 'login.php']);
        exit();
    }
    header("Location: login.php");
    exit();
}

// --- AJAX HANDLER FOR CART ACTIONS ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $response = ['success' => false, 'message' => 'An error occurred.'];
    $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    
    // Initialize cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    switch ($_POST['action']) {
        case 'add':
            $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
            if ($product_id > 0 && $quantity > 0) {
                // Check if product exists and has stock
                $stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
                $stmt->bind_param("i", $product_id);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_assoc();

                if ($result) {
                    $total_qty = (isset($_SESSION['cart'][$product_id]) ? $_SESSION['cart'][$product_id] : 0) + $quantity;
                    if ($result['stock'] >= $total_qty) {
                         $_SESSION['cart'][$product_id] = $total_qty;
                         $response = ['success' => true, 'message' => 'Product added to cart!'];
                    } else {
                        $response['message'] = 'Not enough stock available.';
                    }
                } else {
                    $response['message'] = 'Product not found.';
                }
            }
            break;

        case 'update':
            $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;
            if ($product_id > 0 && array_key_exists($product_id, $_SESSION['cart'])) {
                if ($quantity > 0) {
                     // Check stock
                    $stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
                    $stmt->bind_param("i", $product_id);
                    $stmt->execute();
                    $result = $stmt->get_result()->fetch_assoc();
                    if ($result && $result['stock'] >= $quantity) {
                        $_SESSION['cart'][$product_id] = $quantity;
                        $response = ['success' => true];
                    } else {
                         $response['message'] = 'Not enough stock.';
                    }
                } else { // Remove if quantity is 0 or less
                    unset($_SESSION['cart'][$product_id]);
                    $response = ['success' => true];
                }
            }
            break;

        case 'remove':
            if ($product_id > 0 && isset($_SESSION['cart'][$product_id])) {
                unset($_SESSION['cart'][$product_id]);
                $response = ['success' => true, 'message' => 'Item removed from cart.'];
            }
            break;
    }
    echo json_encode($response);
    exit();
}

// --- DISPLAY CART PAGE ---
include 'common/header.php';

$cart_items = [];
$total_price = 0;
if (!empty($_SESSION['cart'])) {
    $product_ids = implode(',', array_keys($_SESSION['cart']));
    $sql = "SELECT id, name, price, image FROM products WHERE id IN ($product_ids)";
    $result = $conn->query($sql);
    while ($row = $result->fetch_assoc()) {
        $row['quantity'] = $_SESSION['cart'][$row['id']];
        $cart_items[] = $row;
        $total_price += $row['price'] * $row['quantity'];
    }
}
?>

<main class="p-4">
    <h1 class="text-2xl font-bold text-gray-800 mb-4">My Cart</h1>

    <div id="cart-container">
        <?php if (!empty($cart_items)): ?>
            <div class="space-y-3">
            <?php foreach ($cart_items as $item): ?>
                <div class="bg-white rounded-lg shadow-sm p-3 flex items-center" id="item-<?php echo $item['id']; ?>">
                    <img src="uploads/<?php echo htmlspecialchars($item['image']); ?>" class="w-20 h-20 rounded-md object-cover">
                    <div class="flex-1 ml-4">
                        <h2 class="text-md font-semibold text-gray-800"><?php echo htmlspecialchars($item['name']); ?></h2>
                        <p class="text-lg font-bold text-indigo-600"><?php echo format_price($item['price']); ?></p>
                        <div class="flex items-center mt-2">
                            <input type="number" value="<?php echo $item['quantity']; ?>" min="1" onchange="updateCart(<?php echo $item['id']; ?>, this.value)" class="w-16 text-center border rounded-md">
                            <button onclick="removeCartItem(<?php echo $item['id']; ?>)" class="ml-auto text-red-500 hover:text-red-700">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            </div>

            <!-- Cart Summary -->
            <div class="mt-6 bg-white rounded-lg shadow-sm p-4 sticky bottom-20">
                <div class="flex justify-between items-center text-lg font-semibold">
                    <span>Total Amount</span>
                    <span id="total-price"><?php echo format_price($total_price); ?></span>
                </div>
                <a href="checkout.php" class="block w-full mt-4 py-3 text-center text-lg font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition">
                    Proceed to Checkout
                </a>
            </div>
        <?php else: ?>
            <div class="text-center py-16">
                <i class="fas fa-shopping-cart text-6xl text-gray-300"></i>
                <p class="mt-4 text-gray-500">Your cart is empty.</p>
                <a href="index.php" class="mt-6 inline-block px-6 py-2 text-white bg-indigo-500 rounded-md">Shop Now</a>
            </div>
        <?php endif; ?>
    </div>
</main>

<script>
    async function updateCart(productId, quantity) {
        const formData = new FormData();
        formData.append('action', 'update');
        formData.append('product_id', productId);
        formData.append('quantity', quantity);

        const result = await sendRequest('cart.php', { method: 'POST', body: formData });
        if (result.success) {
            // Using page reload for simplicity. A better approach would be to update totals dynamically.
            location.reload(); 
        } else {
            alert(result.message || 'Failed to update cart.');
            location.reload(); // Reload to show correct quantity
        }
    }

    async function removeCartItem(productId) {
        if (!confirm('Are you sure you want to remove this item?')) return;
        
        const formData = new FormData();
        formData.append('action', 'remove');
        formData.append('product_id', productId);

        const result = await sendRequest('cart.php', { method: 'POST', body: formData });
        if (result.success) {
            // Animate removal then reload or dynamically update
            const itemElement = document.getElementById('item-' + productId);
            if(itemElement) {
                itemElement.style.transition = 'opacity 0.5s ease';
                itemElement.style.opacity = '0';
                setTimeout(() => location.reload(), 500);
            } else {
                 location.reload();
            }
        } else {
            alert(result.message || 'Failed to remove item.');
        }
    }
</script>

<?php include 'common/bottom.php'; ?>