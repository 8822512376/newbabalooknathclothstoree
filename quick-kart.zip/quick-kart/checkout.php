<?php
// --- AJAX Handler ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUEST_ED_WITH'])) {
    require_once __DIR__ . '/common/config.php';
    header('Content-Type: application/json');
    if (!is_user_logged_in()) {
        echo json_encode(['success' => false, 'message' => 'Authentication Error.']);
        exit();
    }
    $user_id = get_user_id();
    $address = trim($_POST['address'] ?? '');
    $payment_method = trim($_POST['payment_method'] ?? '');
    $response = ['success' => false];
    if (empty($address) || empty($payment_method)) {
        $response['message'] = "Shipping address and payment method are required.";
    } elseif (empty($_SESSION['cart'])) {
        $response['message'] = "Your cart is empty.";
    } else {
        if ($payment_method === 'UPI') {
            $response = ['success' => true, 'action' => 'show_qr'];
        } else { // COD Logic
            $conn->begin_transaction();
            try {
                $total_amount = 0; $cart_items_details = [];
                $product_ids = implode(',', array_keys($_SESSION['cart']));
                $sql = "SELECT id, name, price, stock FROM products WHERE id IN ($product_ids)";
                $result = $conn->query($sql);
                while ($product = $result->fetch_assoc()) {
                    $quantity = $_SESSION['cart'][$product['id']];
                    if ($product['stock'] < $quantity) { throw new Exception("Not enough stock for {$product['name']}."); }
                    $total_amount += $product['price'] * $quantity;
                    $cart_items_details[] = ['id' => $product['id'], 'price' => $product['price'], 'quantity' => $quantity];
                }
                $stmt_order = $conn->prepare("INSERT INTO orders (user_id, total_amount, shipping_address, status) VALUES (?, ?, ?, 'Placed')");
                $stmt_order->bind_param("ids", $user_id, $total_amount, $address);
                $stmt_order->execute(); $order_id = $stmt_order->insert_id;
                $stmt_items = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt_stock = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
                foreach($cart_items_details as $item) {
                    $stmt_items->bind_param("iiid", $order_id, $item['id'], $item['quantity'], $item['price']);
                    $stmt_items->execute();
                    $stmt_stock->bind_param("ii", $item['quantity'], $item['id']);
                    $stmt_stock->execute();
                }
                $conn->commit(); unset($_SESSION['cart']);
                $response = ['success' => true, 'redirect' => 'order.php?success=true'];
            } catch (Exception $e) {
                $conn->rollback();
                $response['message'] = "Order Failed: " . $e->getMessage();
            }
        }
    }
    echo json_encode($response);
    exit();
}

// --- Page Display Logic ---
require_once __DIR__ . '/common/header.php';
if (!is_user_logged_in()) { header("Location: login.php"); exit(); }
if (empty($_SESSION['cart'])) { header("Location: cart.php"); exit(); }
$user_id = get_user_id();
$user_stmt = $conn->prepare("SELECT name, phone, email, address FROM users WHERE id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user = $user_stmt->get_result()->fetch_assoc();
$total_price = 0;
if (!empty($_SESSION['cart'])) {
    $product_ids = implode(',', array_keys($_SESSION['cart']));
    $sql = "SELECT id, price FROM products WHERE id IN ($product_ids)";
    $result = $conn->query($sql);
    while ($row = $result->fetch_assoc()) { $total_price += $row['price'] * $_SESSION['cart'][$row['id']]; }
}
$whatsapp_number = "918822512376"; 
$whatsapp_message = "Hello, I have completed my payment of " . format_price($total_price) . ". Please confirm my order.";
?>
<!-- The HTML for the page -->
<main class="p-4">
    <h1 class="text-2xl font-bold text-gray-800 mb-4">Checkout</h1>
    <form id="checkout-form">
        <div class="bg-white rounded-lg shadow-sm p-4">
            <h2 class="text-lg font-semibold mb-3">Shipping Information</h2>
            <div class="space-y-4">
                <div><label class="text-sm font-medium text-gray-600">Full Name</label><input type="text" value="<?php echo htmlspecialchars($user['name']); ?>" class="w-full mt-1 p-2 border rounded-md bg-gray-100" readonly></div>
                <div><label class="text-sm font-medium text-gray-600">Phone</label><input type="text" value="<?php echo htmlspecialchars($user['phone']); ?>" class="w-full mt-1 p-2 border rounded-md bg-gray-100" readonly></div>
                <div><label for="address" class="text-sm font-medium text-gray-600">Shipping Address</label><textarea id="address" name="address" rows="3" class="w-full mt-1 p-2 border rounded-md" placeholder="Enter your full address" required><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea></div>
            </div>
        </div>
        <div class="mt-4 bg-white rounded-lg shadow-sm p-4">
            <h2 class="text-lg font-semibold mb-3">Payment Method</h2>
            <div class="space-y-3">
                <label class="flex items-center p-3 border rounded-md has-[:checked]:bg-indigo-50 has-[:checked]:border-indigo-500 transition"><input type="radio" name="payment_method" value="COD" class="h-4 w-4 text-indigo-600" checked><div class="ml-3"><p class="font-medium text-gray-800">Cash on Delivery (COD)</p><p class="text-xs text-gray-500">Pay upon receiving your order.</p></div></label>
                <label class="flex items-center p-3 border rounded-md has-[:checked]:bg-indigo-50 has-[:checked]:border-indigo-500 transition"><input type="radio" name="payment_method" value="UPI" class="h-4 w-4 text-indigo-600"><div class="ml-3"><p class="font-medium text-gray-800">Pay with UPI QR</p><p class="text-xs text-gray-500">Scan and pay with any UPI app.</p></div></label>
            </div>
        </div>
    </form>
    <div class="mt-6 bg-white rounded-lg shadow-sm p-4 sticky bottom-20 border-t">
        <div class="flex justify-between items-center text-lg font-semibold"><span>Total to Pay</span><span><?php echo format_price($total_price); ?></span></div>
        <button id="place-order-btn" class="w-full mt-4 py-3 text-center text-lg font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700">Place Order</button>
    </div>
</main>
<div id="qr-modal-overlay" class="fixed inset-0 bg-black bg-opacity-60 z-50 hidden flex items-center justify-center p-4">
    <div id="qr-modal" class="bg-white rounded-lg shadow-xl p-6 text-center w-full max-w-xs transform scale-95 opacity-0 transition-all duration-300">
        <h2 class="text-xl font-bold text-gray-800">Scan to Pay</h2>
        <img src="assets/upi_qr_code.png" alt="UPI QR Code" class="w-48 h-48 mx-auto my-4 rounded-md border bg-gray-100">
        <p class="text-gray-600 text-sm">Or pay to UPI ID:</p>
        <p class="font-semibold text-gray-800 bg-gray-100 p-2 rounded-md my-2">swapanbaroiii@oksbi</p>
        <p class="font-bold text-2xl text-indigo-600"><?php echo format_price($total_price); ?></p>
        <a href="https://wa.me/<?php echo $whatsapp_number; ?>?text=<?php echo urlencode($whatsapp_message); ?>" target="_blank" class="block w-full mt-6 py-2 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600"><i class="fab fa-whatsapp mr-2"></i>Share Screenshot</a>
        <button id="close-modal-btn" class="mt-3 w-full py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">Close</button>
    </div>
</div>

<!-- ====================================================== -->
<!--             START OF THE JAVASCRIPT FIX                -->
<!-- ====================================================== -->
<script>
    const placeOrderBtn = document.getElementById('place-order-btn');
    const qrModalOverlay = document.getElementById('qr-modal-overlay');
    const qrModal = document.getElementById('qr-modal');
    const closeModalBtn = document.getElementById('close-modal-btn');

    function showQrModal() {
        qrModalOverlay.classList.remove('hidden');
        setTimeout(() => { qrModal.classList.remove('scale-95', 'opacity-0'); qrModal.classList.add('scale-100', 'opacity-100'); }, 50);
    }
    function hideQrModal() {
        qrModal.classList.add('scale-95', 'opacity-0');
        setTimeout(() => { qrModalOverlay.classList.add('hidden'); }, 300);
    }

    // --- NEW, SIMPLIFIED CLICK HANDLER ---
    placeOrderBtn.addEventListener('click', async () => {
        const form = document.getElementById('checkout-form');
        const formData = new FormData(form);
        const paymentMethod = formData.get('payment_method');

        // 1. Validate the address field first
        if (!form.reportValidity()) {
            return; // Stop if the address is empty
        }

        // 2. Check which payment method is selected
        if (paymentMethod === 'UPI') {
            // If UPI, just show the modal directly. No server call needed yet.
            showQrModal();
        } else {
            // If COD, call the server to place the order.
            const result = await sendRequest('checkout.php', { body: formData });
            if (result.success && result.redirect) {
                window.location.href = result.redirect;
            } else {
                alert(result.message || 'Failed to place order.');
            }
        }
    });

    closeModalBtn.addEventListener('click', hideQrModal);
    qrModalOverlay.addEventListener('click', function(event) { if (event.target === qrModalOverlay) { hideQrModal(); } });
</script>
<!-- ====================================================== -->
<!--               END OF THE JAVASCRIPT FIX                -->
<!-- ====================================================== -->

<?php 
$user_stmt->close();
include 'common/bottom.php'; 
?>