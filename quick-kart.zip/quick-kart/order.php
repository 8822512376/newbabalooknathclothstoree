<?php
// This line now correctly includes the header, which in turn includes the config.
require_once __DIR__ . '/common/header.php';

// This will now work because the header has loaded the necessary functions.
if (!is_user_logged_in()) {
    header("Location: login.php");
    exit();
}

$user_id = get_user_id();

// Fetch orders logic... (same as before)
$sql = "SELECT o.id, o.total_amount, o.status, o.created_at, oi.product_id, p.name as product_name, p.image as product_image
        FROM orders o
        JOIN (SELECT order_id, MIN(product_id) as product_id FROM order_items GROUP BY order_id) as oi_first ON o.id = oi_first.order_id
        JOIN order_items oi ON o.id = oi.order_id AND oi.product_id = oi_first.product_id
        JOIN products p ON oi.product_id = p.id
        WHERE o.user_id = ? ORDER BY o.created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$orders_result = $stmt->get_result();

$active_orders = [];
$past_orders = [];
while($order = $orders_result->fetch_assoc()) {
    if (in_array($order['status'], ['Delivered', 'Cancelled'])) {
        $past_orders[] = $order;
    } else {
        $active_orders[] = $order;
    }
}
?>
<!-- The rest of the HTML is the same as before -->
<main class="p-4">
    <h1 class="text-2xl font-bold text-gray-800 mb-4">My Orders</h1>
    <div class="flex border-b mb-4">
        <button onclick="showTab('active')" id="active-tab-btn" class="tab-button flex-1 py-2 font-semibold border-b-2 text-indigo-600 border-indigo-600">Active Orders</button>
        <button onclick="showTab('past')" id="past-tab-btn" class="tab-button flex-1 py-2 font-semibold border-b-2 text-gray-500 border-transparent">Order History</button>
    </div>
    <div id="active-orders" class="tab-content space-y-4">
        <?php if (!empty($active_orders)): foreach($active_orders as $order): ?>
        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="p-3 flex items-start space-x-3"><img src="uploads/<?php echo htmlspecialchars($order['product_image']); ?>" class="w-16 h-16 rounded-md object-cover">
                <div class="flex-1">
                    <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($order['product_name']); ?></h3>
                    <p class="text-sm text-gray-500">Order #<?php echo $order['id']; ?></p>
                    <p class="text-md font-bold text-gray-900 mt-1"><?php echo format_price($order['total_amount']); ?></p>
                </div>
            </div>
            <div class="px-3 pb-4">
                <?php $status = $order['status']; $line_width = 'w-0'; if ($status === 'Dispatched') $line_width = 'w-1/2'; if ($status === 'Delivered') $line_width = 'w-full'; ?>
                <div class="relative w-full">
                    <div class="absolute top-1/2 left-0 w-full h-0.5 bg-gray-200 -translate-y-1/2"></div>
                    <div class="absolute top-1/2 left-0 h-0.5 bg-indigo-600 -translate-y-1/2 transition-all duration-500 <?php echo $line_width; ?>"></div>
                    <div class="flex justify-between items-center relative">
                        <div class="text-center"><div class="w-6 h-6 rounded-full bg-white border-2 border-indigo-600 flex items-center justify-center mx-auto"><div class="w-3 h-3 bg-indigo-600 rounded-full"></div></div><p class="text-xs mt-1 text-indigo-600">Placed</p></div>
                        <div class="text-center"><div class="w-6 h-6 rounded-full bg-white border-2 flex items-center justify-center mx-auto <?php echo $status !== 'Placed' ? 'border-indigo-600' : 'border-gray-300'; ?>"><?php if($status !== 'Placed'): ?><div class="w-3 h-3 bg-indigo-600 rounded-full"></div><?php endif; ?></div><p class="text-xs mt-1 <?php echo $status !== 'Placed' ? 'text-indigo-600' : 'text-gray-400'; ?>">Dispatched</p></div>
                        <div class="text-center"><div class="w-6 h-6 rounded-full bg-white border-2 flex items-center justify-center mx-auto <?php echo $status === 'Delivered' ? 'border-indigo-600' : 'border-gray-300'; ?>"><?php if($status === 'Delivered'): ?><div class="w-3 h-3 bg-indigo-600 rounded-full"></div><?php endif; ?></div><p class="text-xs mt-1 <?php echo $status === 'Delivered' ? 'text-indigo-600' : 'text-gray-400'; ?>">Delivered</p></div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; else: ?>
        <p class="text-center text-gray-500 pt-8">No active orders found.</p>
        <?php endif; ?>
    </div>
    <div id="past-orders" class="tab-content space-y-4 hidden">
        <?php if (!empty($past_orders)): foreach($past_orders as $order): ?>
        <div class="bg-white rounded-lg shadow-sm p-3 flex items-center space-x-4"><img src="uploads/<?php echo htmlspecialchars($order['product_image']); ?>" class="w-16 h-16 rounded-md object-cover">
            <div class="flex-1">
                <h3 class="font-semibold text-gray-700 truncate"><?php echo htmlspecialchars($order['product_name']); ?></h3>
                <p class="text-sm text-gray-500"><span class="font-bold <?php echo $order['status'] === 'Delivered' ? 'text-green-600' : 'text-red-500'; ?>"><?php echo $order['status']; ?></span> on <?php echo date('d M, Y', strtotime($order['created_at'])); ?></p>
            </div><i class="fas fa-chevron-right text-gray-400"></i>
        </div>
        <?php endforeach; else: ?>
        <p class="text-center text-gray-500 pt-8">No past orders found.</p>
        <?php endif; ?>
    </div>
</main>
<script>
    function showTab(tabName) {
        document.getElementById('active-orders').classList.add('hidden');
        document.getElementById('past-orders').classList.add('hidden');
        document.getElementById('active-tab-btn').classList.remove('text-indigo-600', 'border-indigo-600');
        document.getElementById('active-tab-btn').classList.add('text-gray-500', 'border-transparent');
        document.getElementById('past-tab-btn').classList.remove('text-indigo-600', 'border-indigo-600');
        document.getElementById('past-tab-btn').classList.add('text-gray-500', 'border-transparent');
        document.getElementById(tabName + '-orders').classList.remove('hidden');
        document.getElementById(tabName + '-tab-btn').classList.add('text-indigo-600', 'border-indigo-600');
    }
</script>
<?php
$stmt->close();
include 'common/bottom.php'; 
?>